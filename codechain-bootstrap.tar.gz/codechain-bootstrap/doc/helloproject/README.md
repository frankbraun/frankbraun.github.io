## Example project for Codechain walkthrough
