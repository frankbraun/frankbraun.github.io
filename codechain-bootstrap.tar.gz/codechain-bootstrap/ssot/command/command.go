// Package command implements the ssotpub commands.
package command
