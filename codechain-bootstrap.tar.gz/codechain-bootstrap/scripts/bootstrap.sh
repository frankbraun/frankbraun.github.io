#!/bin/sh -ex

cd /tmp
rm -f cctreehash.go
curl -O https://frankbraun.org/cctreehash.go
CCTREEHASH=$(sha256sum cctreehash.go)
if [ "$CCTREEHASH" = "6a911b51cc047eea7d7b10c75cf1f50a98dea2a39e12ef3414d2f00f31a263f9  cctreehash.go" ]
then
  echo "sha256 cctreehash.go matches"
else
  echo "sha256 cctreehash.go does not match"
  exit 1
fi
rm -rf codechain-bootstrap
curl -O https://frankbraun.org/codechain-bootstrap.tar.gz
tar xzf codechain-bootstrap.tar.gz
cd codechain-bootstrap
CODECHAIN_BOOTSTRAP=$(go run ../cctreehash.go)
if [ "$CODECHAIN_BOOTSTRAP" = "6a911b51cc047eea7d7b10c75cf1f50a98dea2a39e12ef3414d2f00f31a263f9" ]
then
  echo "codechain-bootstrap tree hash matches"
else
  echo "codechain-bootstrap tree hash does not match"
  exit 1
fi
go run cmd/secpkg/secpkg.go install .secpkg
cd ..
rm -rf codechain-bootstrap
rm -f cctreehash.go
