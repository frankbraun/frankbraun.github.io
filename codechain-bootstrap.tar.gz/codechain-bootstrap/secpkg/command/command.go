// Package command implements the secpkg commands.
package command
